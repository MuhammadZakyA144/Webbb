# MIE GACORAN — versi HTML, CSS, JS
# MIE GACORAN — Versi HTML, CSS, JS

Versi website MIE GACORAN tanpa framework. Cukup buka `index.html` di browser,
atau unggah seluruh isi folder ini ke hosting mana pun.
Tersedia dalam dua format tanpa framework:

### 1. Versi 1 File (Single File — Semua dalam 1 Berkas)
- `mie-gacoran.html` (tersedia juga di root `/mie-gacoran.html` dan `/mie-gacoran.html` di web):
  Seluruh kode website (HTML, CSS di dalam `<style>`, dan JavaScript di dalam `<script>`) telah disatukan dalam **1 file tunggal**.
  Cukup klik 2x berkas `mie-gacoran.html` untuk langsung dibuka di browser apa pun di HP maupun komputer/laptop tanpa perlu web server atau instalasi Node.js/npm.

### 2. Versi Terpisah (Modular)
- `index.html` — struktur halaman
- `style.css` — semua tampilan (warna, font, layout, responsif)
- `script.js` — data menu & harga, keranjang, dan kirim pesanan ke WhatsApp
- `img/` — foto makanan dan minuman

Untuk mengubah harga, deskripsi, atau nomor WhatsApp, edit bagian paling atas `script.js`.
Untuk mengubah harga, deskripsi, atau nomor WhatsApp pada versi 1 file (`mie-gacoran.html`), buka file tersebut dengan editor teks (Notepad, VS Code, dll) dan edit konstanta di bagian `<script>`.