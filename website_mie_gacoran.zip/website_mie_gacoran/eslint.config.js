

export default tseslint.config(
  {
    ignores: ['dist/**', '.netlify/**', '.tanstack/**', 'src/routeTree.gen.ts'],
    ignores: ['dist/**', '.netlify/**', '.tanstack/**', 'src/routeTree.gen.ts', 'public/**'],
  },
  js.configs.recommended,
  ...tseslint.configs.recommended,