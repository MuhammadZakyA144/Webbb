

TanStack Start (React 19), Tailwind CSS 4, lucide-react, sonner, di-deploy di Netlify. Foto ditayangkan lewat Netlify Image CDN.

## Versi Tanpa Framework (1 File HTML)

Jika ingin menjalankan atau membagikan website dalam **1 file saja** tanpa build tool, gunakan berkas:
- **`mie-gacoran.html`** (juga tersedia di `public/mie-gacoran.html` dan dapat diakses online di `https://miegacoran01.netlify.app/mie-gacoran.html`).
- Seluruh kode HTML, CSS, dan JavaScript sudah digabung menjadi satu di dalamnya. Cukup klik ganda (double-click) untuk membukanya di browser apa pun.

## Menjalankan secara lokal

```bash